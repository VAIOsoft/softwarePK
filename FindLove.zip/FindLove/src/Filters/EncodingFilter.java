package Filters;
import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EncodingFilter implements Filter
{
	String encoding="ISO-8859-1";
	
	public void destroy()
	{
		
	}

	public void doFilter(ServletRequest request, ServletResponse response,FilterChain chain) throws IOException, ServletException
	{
		HttpServletRequest request_1 = (HttpServletRequest) request;
		HttpServletResponse response_1 = (HttpServletResponse) response;
		request_1.setCharacterEncoding(encoding);
		response_1.setCharacterEncoding(encoding);
		chain.doFilter(request, response);
	}
	
	public void init(FilterConfig config) throws ServletException 
	{
		String str = config.getInitParameter("encoding");
		if (str != null && str.length() > 0) 
		{   
			encoding = str;
		}
	} 
}

package Javabean;

import java.awt.List;
import java.util.ArrayList;

public class Register 
{
	String logname="",sex="",message="";
	int backNews=1;
	int age=0;
	long phone=0;
	
	//List mylist =new ArrayList();
	
	public void setLogname(String logname) 
	{
		this.logname=logname;
	}
	
	public String getLogname() 
	{
		return logname;
	}
	
	public void setSex(String sex) 
	{
		this.sex=sex;
	}
	
	public String getSex() 
	{
		return sex;
	}
	
	public void setMesage(String message) 
	{
		this.message=message;
	}
	
	public String getMessage()
	{
		return message;
	}
	
	public void setAge(int age) 
	{
		this.age=age;
		if (age<0||age>120) 
		{
			setBackNews(0);
		}
	}
	
	public int getAge() 
	{
		return age;
	}
	
	public void setPhone(long phone)
	{
		this.phone=phone;
		if (phone<0)
		{
			setBackNews(0);
		}
	}
	
	public long getPhone()
	{
		return phone;
	}
	
	public void setBackNews(int backNews) 
	{
		this.backNews=backNews;
	}
	
	public int getBackNews() 
	{
		return this.backNews;
	}
}

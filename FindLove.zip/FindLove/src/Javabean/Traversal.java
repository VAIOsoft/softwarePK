package Javabean;

public class Traversal
{
	public static boolean matchString(String target, String mode) 
	{  	
		int i = 0;
		int flag = 0;
		char blank =' ';
		while (i<mode.length())
		{
			if (mode.charAt(i)!=blank)
			{
				for (int k = 0; k < target.length(); k++)
				{
					if (target.charAt(k)==mode.charAt(i))
					{
						flag++;
					}
				}
			}
			i++;
		}
		
		if (flag>=2)
		{
			return true;
		}
		return false;
	}  
}

package Javabean;

public class KMP
{  
	public static boolean matchString(String target, String mode) 
	{  
	    String newTarget = "x" + target; 
	    String newMode = 'x' + mode;
	          
	    int[] Next = calculateNext(mode);
	    for (int i = 0; i < Next.length; i++)
		{
	    	int temp = Next[i];
	    	if (temp>=2)
			{
				return true;
			}
		}
	    int i = 1;
	    int j = 1;
	    while(i <= target.length() && j <= mode.length()) 
	    {  
	    	if (j == 0 || newTarget.charAt(i) == newMode.charAt(j)) 
	    	{
	    		i++;  
	            j++;  
	        } 
	    	else 
	    	{  
	    		j = Next[j];
	        } 
	    }

	    if (j > mode.length()) 
	    {  
	    	return true;  
	    }  
	    return false;  
	}  
	      
	private static int[] calculateNext(String mode)
	{
	    String newMode = "x" + mode;  
	    int[] Next = new int[newMode.length()];  
	    int i = 1;  
	    Next[1] = 0;  
	    int j = 0;  
	          
	    while(i < mode.length()) 
	    {  
	    	if (j == 0 || newMode.charAt(i) == newMode.charAt(j))
	    	{  
	    		i++;  
	            j++;  
	            Next[i] = j;  
	        } 
	    	else 
	    	{  
	            j = Next[j];
	        }  
	    }  
	    return Next;  
	}  
}
